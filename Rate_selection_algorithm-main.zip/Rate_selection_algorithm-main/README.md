# Rate_selection_algorithm
Thuật toán Gen - Thuật toán chọn lọc tỉ lệ (Trí tuệ nhân tạo)
+ Tác giả: Nguyễn Hùng Dũng                     
+ Tham khảo mục Initialize Population, Crossover và Mutation từ tác giả Shu-Chuan Chu, Chin-Shiuh Shieh, and John F. Roddick, sách "A Tutorial on Meta-Heuristics for Optimization"
